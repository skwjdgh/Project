# backend/fingerprint_service.py

import os
import json
import glob
import asyncio
from enum import Enum
from loguru import logger
from typing import List

# FastAPI의 WebSocket을 사용하기 위해 import
from fastapi import WebSocket

# Fingerprint 유틸리티 임포트
from Utility.Fingerprint import (
    initialize_sensor,
    get_sensor_connection,
    verify_fingerprint,
)

# --- 경로 설정 ---
SERVICE_FILE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.abspath(os.path.join(SERVICE_FILE_DIR, ".."))
DATA_FP_PATH = os.path.join(ROOT_DIR, 'data_fp')

# 1. 지문인식 센서의 상태를 정의
class FingerprintState(str, Enum):
    FP_IDLE = "fp_idle"
    FP_READY = "fp_ready"
    FP_VERIFYING = "fp_verifying"
    FP_RETRY = "fp_retry"
    FP_RESET = "fp_reset"
    FP_SUCCESS = "fp_success"
    FP_FAIL = "fp_fail"

# [수정 1] WebSocket 연결을 관리하는 클래스 추가
class WebSocketConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
        logger.info("WebSocket 클라이언트 연결됨")

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)
        logger.info("WebSocket 클라이언트 연결 끊김")

    async def broadcast(self, data: dict):
        # 연결된 모든 클라이언트에게 JSON 데이터를 전송
        for connection in self.active_connections:
            await connection.send_json(data)

# --- 전역 변수 및 관리 객체 ---
fp_sensor = None
fp_current_state: FingerprintState = FingerprintState.FP_IDLE
fp_lock = asyncio.Lock()
fp_connection_manager = WebSocketConnectionManager() # WebSocket 매니저 인스턴스 생성


def get_current_fp_state() -> FingerprintState:
    return fp_current_state

# [수정 2] 상태 변경 및 브로드캐스트를 중앙에서 처리하는 함수
async def _set_fp_state_and_broadcast(state: FingerprintState, data: dict = None):
    """상태를 변경하고 모든 클라이언트에게 즉시 알립니다."""
    global fp_current_state
    fp_current_state = state
    
    # 브로드캐스트할 메시지 구성
    message = {"status": state.value}
    if data:
        message.update(data)
        
    await fp_connection_manager.broadcast(message)
    logger.info(f"상태 변경 및 브로드캐스트: {state.value}")


def init_fingerprint_engine():
    global fp_sensor
    logger.info("지문 인식 엔진 초기화를 시도합니다...")
    fp_sensor = initialize_sensor()
    if fp_sensor:
        logger.info("지문 인식 엔진 초기화 완료.")
        # 초기 상태는 _set_fp_state_and_broadcast를 사용하지 않음 (연결 전)
        global fp_current_state
        fp_current_state = FingerprintState.FP_IDLE
        return True
    else:
        logger.error("지문 인식 엔진 초기화 실패.")
        fp_current_state = FingerprintState.FP_FAIL
        return False

def get_enrolled_fingerprints():
    if not os.path.exists(DATA_FP_PATH):
        logger.error(f"지문 데이터 폴더({DATA_FP_PATH})를 찾을 수 없습니다.")
        return []
    user_list = []
    json_files = glob.glob(os.path.join(DATA_FP_PATH, '*.json'))
    for file_path in json_files:
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                user_list.append({
                    "file_name": os.path.basename(file_path),
                    "name": data.get('name', 'N/A'),
                    "rrn": data.get('rrn', 'N/A')
                })
        except Exception as e:
            logger.error(f"파일 처리 중 오류: {file_path}, {e}")
    return user_list

# [수정 3] Lock 사용법 수정 및 WebSocket 상태 전파 로직 추가
async def run_fingerprint_verification():
    """
    지문 인식 프로세스를 실행하고, 각 단계별 상태를 WebSocket으로 전파합니다.
    """
    global fp_sensor

    # 올바른 Lock 사용: Lock이 점유 중이면 여기서 대기함. if문 불필요.
    async with fp_lock:
        # 이 블록은 한 번에 하나의 작업만 진입할 수 있음
        fp_sensor = get_sensor_connection()
        if not fp_sensor:
            await _set_fp_state_and_broadcast(FingerprintState.FP_FAIL, {"error": "SENSOR_NOT_CONNECTED"})
            return

        try:
            await _set_fp_state_and_broadcast(FingerprintState.FP_READY)
            await asyncio.sleep(1)
            
            await _set_fp_state_and_broadcast(FingerprintState.FP_VERIFYING)
            
            result = await asyncio.to_thread(verify_fingerprint, fp_sensor)
            
            if result and result.get("success"):
                await _set_fp_state_and_broadcast(FingerprintState.FP_SUCCESS, result)
            else:
                # result가 None일 수 있으므로 기본값 제공
                error_data = result if result else {"error": "Verification process failed."}
                await _set_fp_state_and_broadcast(FingerprintState.FP_FAIL, error_data)

        except Exception as e:
            logger.error(f"지문 인식 프로세스 중 예외 발생: {e}")
            await _set_fp_state_and_broadcast(FingerprintState.FP_FAIL, {"error": str(e)})
        finally:
            # 최종 상태를 전송 후 일정 시간 뒤 IDLE 상태로 전환
            await asyncio.sleep(2)
            await _set_fp_state_and_broadcast(FingerprintState.FP_IDLE)