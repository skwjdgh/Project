기존 Utility폴더 내 AUTH 폴더 삭제할 것

requirements.txt 는 
pip install -r requirements.txt로 의존성 설치 가능함 